package app;

import gui.main.form.MainFrame;

public class Application {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		MainFrame.getInstance().setVisible(true);
	}

}
