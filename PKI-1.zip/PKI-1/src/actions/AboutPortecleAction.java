package actions;

import java.awt.event.ActionEvent;

import javax.swing.AbstractAction;

public class AboutPortecleAction extends AbstractAction {
	
	public AboutPortecleAction() {
		
		putValue(NAME, "About Portecle");
	}

	public void actionPerformed(ActionEvent arg0) {
		// TODO Auto-generated method stub
		
	}

}
