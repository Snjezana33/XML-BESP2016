package actions;

import java.awt.event.ActionEvent;

import javax.swing.AbstractAction;
import javax.swing.KeyStroke;

public class ChangeKeystTypeAction extends AbstractAction {

	public ChangeKeystTypeAction() {
		
		putValue(NAME, "Change Keystore Type");
		this.setEnabled(false);
		
	}
	
	public void actionPerformed(ActionEvent arg0) {
		// TODO Auto-generated method stub
		
	}

}
