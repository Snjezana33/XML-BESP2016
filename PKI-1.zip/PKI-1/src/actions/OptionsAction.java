package actions;

import java.awt.event.ActionEvent;

import javax.swing.AbstractAction;

public class OptionsAction extends AbstractAction {

	public OptionsAction() {
		putValue(NAME, "Options...");
		
	}
	
	public void actionPerformed(ActionEvent arg0) {
		// TODO Auto-generated method stub
		
	}

}
