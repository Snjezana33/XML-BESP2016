package actions;

import java.awt.event.ActionEvent;

import javax.swing.AbstractAction;

public class OnlineResourcesAction extends AbstractAction {
	
	public OnlineResourcesAction() {
		
		putValue(SHORT_DESCRIPTION, "Online Resources");
		putValue(NAME, "Online Resources");
	}

	public void actionPerformed(ActionEvent arg0) {
		// TODO Auto-generated method stub
		
	}
	

}
